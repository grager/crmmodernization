# CRM Modernization - V2

Some new services has been created and accessed by the iOS application
