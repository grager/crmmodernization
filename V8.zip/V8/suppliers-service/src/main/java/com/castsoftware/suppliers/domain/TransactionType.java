package io.pivotal.portfolio.domain;

public enum TransactionType {
	DEBIT,CREDIT
}
