# suppliers-service
This service is a spring boot application responsible for managing suppliers
