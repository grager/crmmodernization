package com.castsoftware.crm.dataclasses.crmlayouts


import com.google.gson.annotations.SerializedName

class AutoNumber(
)