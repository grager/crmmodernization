package com.castsoftware.crm

class ApiEssentials{

    companion object{
        const val BASE_URL : String = "https://castapis/"
        var oauthToken : String = "1002.96d8c6d227ee39627667338da74545de.8521df296b891316e18a2ad34b440283"
        val header = HashMap<String,String>()
    }

}
