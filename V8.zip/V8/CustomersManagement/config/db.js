module.exports = {
	url: 'mongodb://localhost/mean-customer'
}
