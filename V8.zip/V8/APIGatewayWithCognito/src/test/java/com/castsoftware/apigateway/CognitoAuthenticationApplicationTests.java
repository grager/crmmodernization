package com.castsoftware.apigateway;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class CognitoAuthenticationApplicationTests {

	@Test
	public void contextLoads() {
	}

}

