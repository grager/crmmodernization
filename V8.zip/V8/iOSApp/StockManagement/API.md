#  API Gateway

auth - POST 
auth/signup - POST
auth/signout - POST
auth/confirmresetpassword - POST
auth/resetpassword - POST

suppliers - GET, POST, PUT, DELETE
stocks - GET, POST, PUT, DELETE
customers - GET, POST, PUT, DELETE
