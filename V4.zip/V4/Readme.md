# CRM Modernization - V4

Introducing a new application to manage the authentication on the mobile side. This new service is run on premise using Spring Boot JWT technology. Implementation not yet done on iOS.
