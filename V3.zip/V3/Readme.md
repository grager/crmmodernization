# CRM Modernization - V3

A new Customer service has been created using MEAN stack to replace the legacy one. Now the iOS application will call the customer services to get the information.
