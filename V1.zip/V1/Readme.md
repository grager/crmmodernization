# CRM Modernization - V1

The mainframe project has been slightly exposed to mobile applications thanks to a new layer written in Java/Spring MVC
