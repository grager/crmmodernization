# CRM Modernization - V5

This time, iOS application will check the authentication before accessing the services
